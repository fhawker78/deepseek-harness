/**
 * Auto-correct middleware, guard-tier. Two layers:
 *
 * 1. A `tools/pre-execute` waterfall listener that intercepts malformed
 *    shell-tool arguments (the recurring `arguments.command` written as a
 *    wrapped `{"command": ...}` JSON envelope or a non-text value) and DENIES
 *    the call with an actionable correction hint naming the exact repaired
 *    command to retry with. The harness freezes parsed arguments before
 *    policy, so the middleware corrects by steer-and-retry — the denial is
 *    the corrected instruction, and the agent loop feeds it back to the model
 *    deterministically, which is why the next attempt usually carries the
 *    repaired value. Silent in-place rewriting is architecturally excluded
 *    (see `PreToolDecision`'s contract).
 *
 * 2. A system-prompt section (order 100, immediately after the deployment
 *    persona) stating the hygiene rules, so most malformed calls never happen.
 *
 * @module @deepseek-ai/dsh-auto-correct
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { coerceIssue, commandIssue, containsJsonEnvelope, unwrapCommand } from './corrections.ts';
export { coerceIssue, commandIssue, containsJsonEnvelope, unwrapCommand };
export type { AutoCorrectIssue } from './corrections.ts';
/** Cordis plugin name. */
export declare const name = "auto-correct";
/** The prompt registry this guard contributes its hygiene section to. */
export declare const inject: readonly ["systemPrompt"];
/** Plugin config. */
export interface Config {
    /** Tool names the middleware polices (default `['pwsh']`). */
    tools?: string[];
    /** Register the prompt hygiene section (default `true`). */
    promptSection?: boolean;
    /** Deny malformed calls with a correction hint (default `true`). */
    denyMalformed?: boolean;
    /**
     * Apply type coercion to EVERY tool call: stringified numbers in numeric
     * fields and `"true"`/`"false"` strings in boolean fields are denied with
     * the full corrected arguments JSON (default `true`).
     */
    coerceTypes?: boolean;
}
export declare const Config: z<Config>;
/**
 * Install the guard's listeners and prompt contribution.
 * @param ctx - plugin context; listeners are scoped to it and disposed with it.
 * @param config - validated {@link Config}; re-checked fail-loud in `apply`.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map
/**
 * Pure correction logic for the auto-correct guard: detection of the known
 * malformed tool-call argument shapes and the corrected command text a denied
 * call should retry with. Kept free of any runtime imports so unit tests can
 * exercise every branch without mounting a harness.
 * @module @deepseek-ai/dsh-auto-correct/corrections
 */
/** One detected, correctable defect in a policed tool call. */
export interface AutoCorrectIssue {
    /** The tool whose arguments carry the defect. */
    readonly tool: string;
    /** Human-readable statement of what is wrong (model-facing). */
    readonly problem: string;
    /** The corrected value the model should retry with ('' when not recoverable). */
    readonly corrected: string;
    /** Full corrected arguments object the model may copy verbatim, when recoverable. */
    readonly correctedArguments?: Record<string, unknown>;
}
/**
 * Unwrap a command value that arrived inside a JSON envelope:
 * - a string that parses as a JSON object with a `command`/`cmd` key;
 * - an object with a string `command`/`cmd` property.
 * Returns the inner plain command text, or `undefined` when the value is
 * already a plain, usable command.
 */
export declare function unwrapCommand(value: unknown): string | undefined;
/**
 * A hard heuristic for an envelope that survived inside a longer command
 * string (e.g. `Get-Process {"command": "..."}`): JSON envelope syntax that
 * the model should never place inside a command text.
 */
export declare function containsJsonEnvelope(text: string): boolean;
/**
 * Inspect the parsed `arguments` of a policed shell tool call. Returns the
 * defect and its repair when the `command` payload is wrapped or non-text;
 * `undefined` when the call is clean (the middleware should delegate).
 */
export declare function commandIssue(args: unknown): AutoCorrectIssue | undefined;
/**
 * Type-coercion defect detection, applied to EVERY tool call: an argument with
 * a known numeric field name whose value is a stringified number, or a known
 * boolean field name whose value is a `"true"`/`"false"` string, is the
 * recurring `invalid arguments: "X" must be a number/boolean` defect. The
 * repair is the full corrected arguments object the model can copy verbatim.
 */
export declare function coerceIssue(tool: string, args: unknown): AutoCorrectIssue | undefined;
//# sourceMappingURL=corrections.d.ts.map